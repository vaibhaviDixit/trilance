<?php
 
 include ($_SERVER['DOCUMENT_ROOT'].'/includes/header.php');

?>



  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">

      <div class="section-title">
          <span>Trilance</span>
          <h2>Welcome To Trilance IT Solutions</h2>
          <p> Best Training Institute in India</p>
        </div>

      <div class="container">

        <div class="row">
          <div class="col-lg-4 order-1 order-lg-2" data-aos="fade-left" style="text-align: center;padding:4rem 2rem;">
            <img src="assets/img/about2.png" class="img-fluid" alt="" >
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content" data-aos="fade-right">
           
            <p>We "Trilance IT Solutions"providing IT training services to college students and company employees to improve their skills & quality.<br/><br/>
The professionals trainers/ faculties are having ample experience to guide candidates about work culture of most IT companies. Candidates will easily get servive in the industry due to our live project experience and placement assistance. <br/><br/>"Trilance IT Solutions" believes in excellance so we train the candidates to get most attractive packages/salary in companies across India.

            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

 

  </main><!-- End #main -->
<?php
 
 include ($_SERVER['DOCUMENT_ROOT'].'/includes/footer.php');

?>