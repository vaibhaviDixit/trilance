<?php

// define constants here
define('SITE_NAME','Trilance');
define('SITE_PATH','http://localhost/Trilance/');
// define('SITE_PATH','https://trilance.000webhostapp.com/');

define('SERVER_PATH',$_SERVER['DOCUMENT_ROOT'].'/Trilance/');

//path to upload images of testimonial
define('SERVER_TESTI_IMAGE',SERVER_PATH."assets/media/testimonials/");
//path to retrieve images of testimonial
define('SITE_TESTI_IMAGE',SITE_PATH."assets/media/testimonials/");

//path to upload images of testimonial
define('SERVER_COURSE_IMAGE',SERVER_PATH."assets/media/course/");
//path to retrieve images of testimonial
define('SITE_COURSE_IMAGE',SITE_PATH."assets/media/course/");


?>

