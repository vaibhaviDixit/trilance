<?php
//connect with database
$con=mysqli_connect('localhost:3309','root','','trilance');

//username: id18760813_trilanceitsolutions	
//password: o?9[1{2]+&aYZ0j*
//db : id18760813_trilance
// $con=mysqli_connect('localhost','id18760813_trilanceitsolutions','o?9[1{2]+&aYZ0j*','id18760813_trilance');
?>